DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'awswiki_db',
        'USER': 'root',
        'PASSWORD': 'pass123#',
        'HOST': 'localhost',
        'PORT': '3306'
    }
}

SECRET_KEY = 'django-insecure-k1_u6012qar0m!0!c=ibszh7*(rx897%6f59wl9&8guvr%mszr'